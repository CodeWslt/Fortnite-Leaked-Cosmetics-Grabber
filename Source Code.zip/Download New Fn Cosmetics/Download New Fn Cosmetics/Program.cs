﻿using Newtonsoft.Json.Linq;
using System;
using System.Net;

namespace Download_New_Fn_Cosmetics
{
    class Program
    {
        ///This Project Uses NewtonSoft And Fortnite-Api
        ///This Program Was Created By Wslt#1056
        public static WebClient w = new WebClient();
        public static string FortniteApi = w.DownloadString("https://fortnite-api.com/v2/cosmetics/br/new");
        static void Main(string[] args)
        {
            var jsonObject = JObject.Parse(FortniteApi);
            Console.WriteLine("Fetching All Leaked Cosmetics For Build " + jsonObject["data"]["build"]);
            FetchImages();
            Console.WriteLine("Grabbed All New Items!");
            Console.ReadLine();
        }

        public static void FetchImages()
        {
            var jsonObject = JObject.Parse(FortniteApi);
            foreach (var Cosmetics in jsonObject["data"]["items"])
            {
                w.DownloadFile((string)Cosmetics["images"]["icon"], (string)Cosmetics["name"] + ".png");
                Console.WriteLine(Cosmetics["images"]["icon"]);
            }
        }
    }
}
